package com.ucdavisgdsc.paradise.chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
