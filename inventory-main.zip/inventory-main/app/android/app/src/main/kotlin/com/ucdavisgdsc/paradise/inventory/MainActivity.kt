package com.ucdavisgdsc.paradise.inventory

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
