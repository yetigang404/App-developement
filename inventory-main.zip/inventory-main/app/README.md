# inventory

A new Flutter project.

### Generating code
`flutter pub run build_runner build`