# backend

setup dev vars: `$(gcloud beta emulators datastore env-init --data-dir .emulator)`

start emulator `gcloud beta emulators datastore start --data-dir .emulator`